create
    definer = root@localhost procedure delete_plageHoraire(IN p_id_plage_horaire char(20))
BEGIN
    DELETE FROM Inoccupable WHERE id_plage_horaire = p_id_plage_horaire;
    DELETE FROM Reservation WHERE id_plage_horaire = p_id_plage_horaire;
    DELETE FROM louer WHERE id_plage_horaire = p_id_plage_horaire;
    DELETE FROM retirer WHERE id_plage_horaire = p_id_plage_horaire;
    DELETE FROM Plage_horaire WHERE id_plage_horaire = p_id_plage_horaire;
    DELETE FROM possede WHERE id_plage_horaire = p_id_plage_horaire;
END;

