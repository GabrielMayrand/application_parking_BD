create
    definer = root@localhost procedure select_parkingList(IN p_prixMin double, IN p_prixMax double,
                                                          IN p_longueur double, IN p_largeur double,
                                                          IN p_hauteur double, IN p_joursAvance int, IN p_dateFin date)
BEGIN
    DROP TABLE IF EXISTS tempStationnement;
    CREATE TEMPORARY TABLE IF NOT EXISTS tempStationnement AS (SELECT * FROM stationnement);
    SELECT * FROM tempStationnement;
    IF p_prixMin is not NULL and p_prixMax is not NULL THEN
        DELETE FROM tempStationnement WHERE id_stationnement NOT IN
                                        (SELECT id_stationnement FROM stationnement WHERE p_prixMin <= prix
                                                                                      AND p_prixMax >= prix);
    END IF ;
    IF p_longueur is not NULL and p_largeur is not NULL and p_hauteur is not NULL THEN
        DELETE FROM tempStationnement WHERE id_stationnement NOT IN
                                        (SELECT id_stationnement FROM stationnement WHERE longueur <= p_longueur
                                                                                      AND largeur <= p_largeur
                                                                                      AND hauteur <= p_hauteur);
    END IF ;
    IF p_joursAvance is not NULL THEN
        DELETE FROM tempStationnement WHERE id_stationnement NOT IN
                                        (SELECT id_stationnement FROM stationnement WHERE jours_d_avance <= p_joursAvance);
    END IF ;
    IF p_dateFin is not NULL THEN
        DELETE FROM tempStationnement WHERE id_stationnement NOT IN
                                        (SELECT id_stationnement FROM stationnement WHERE date_fin >= p_dateFin);
    END IF ;
    SELECT * FROM tempStationnement;
END;

