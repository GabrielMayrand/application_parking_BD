create
    definer = root@localhost procedure delete_stationnement(IN p_id_stationnement char(32))
BEGIN
    DECLARE cur_is_done BOOLEAN DEFAULT FALSE;
    DECLARE cur_id_plage_horaire CHAR(32);
    DECLARE cur CURSOR FOR SELECT id_plage_horaire FROM Possede WHERE id_stationnement = p_id_stationnement;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_is_done = TRUE;
    OPEN cur;
    DELETE FROM stationnement WHERE id_stationnement = p_id_stationnement;
    DELETE FROM gerer WHERE id_stationnement = p_id_stationnement;
    boucle: LOOP
        FETCH cur INTO cur_id_plage_horaire;
        IF cur_is_done THEN
            LEAVE boucle;
        END IF;
        call delete_plageHoraire (cur_id_plage_horaire);
   END LOOP boucle;
   CLOSE cur;
END;

