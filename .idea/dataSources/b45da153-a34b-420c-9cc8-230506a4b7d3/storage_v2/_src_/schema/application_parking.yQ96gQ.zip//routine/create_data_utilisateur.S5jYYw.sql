create
    definer = root@localhost procedure create_data_utilisateur(IN donnees int, IN p_courriel char(50), IN p_id_utilisateur char(32))
BEGIN
    INSERT INTO Utilisateur (id_utilisateur, token, courriel, nom, prenom, mot_de_passe)
        VALUE (p_id_utilisateur, sha1(p_courriel), p_courriel, 'Monsieur', CONCAT('Test', donnees), 'password');
    IF (donnees % 2) = 0 THEN
        INSERT INTO Locateur (id_utilisateur, cote) VALUES (p_id_utilisateur, NULL);
    ELSE
        INSERT INTO Locataire (id_utilisateur) VALUES (p_id_utilisateur);
    END IF;
END;

