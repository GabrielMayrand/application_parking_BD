create
    definer = root@localhost procedure delete_voiture(IN p_voiture_id char(6))
BEGIN
    DELETE FROM vehicule WHERE plaque = p_voiture_id;
    DELETE FROM Appartient WHERE plaque = p_voiture_id;
END;

