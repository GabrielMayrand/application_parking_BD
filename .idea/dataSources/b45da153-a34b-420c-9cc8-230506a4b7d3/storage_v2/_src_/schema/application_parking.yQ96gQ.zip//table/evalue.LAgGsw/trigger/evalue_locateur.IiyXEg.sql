create definer = root@localhost trigger Evalue_locateur
    after insert
    on evalue
    for each row
BEGIN
    UPDATE Locateur L SET L.cote = (SELECT AVG(E.cote) FROM Evalue E WHERE E.id_utilisateur_locateur = L.id_utilisateur)
        WHERE L.id_utilisateur = NEW.id_utilisateur_locateur;
END;

