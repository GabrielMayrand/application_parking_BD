create
    definer = root@localhost procedure create_data_plageHoraire(IN donnees int)
BEGIN
    DECLARE _date_arrivee, _date_depart char(50);
    SET _date_arrivee = CONCAT('2022-', donnees % 12, '-', donnees % 28, ' ', donnees % 24, ':', donnees % 60, ':00');
    SET _date_depart = CONCAT('2022-', donnees % 12, '-', donnees % 28, ' ', donnees % 24, ':', donnees % 60, ':00');
    INSERT INTO Plage_horaire (id_plage_horaire, date_arrivee, date_depart)
        VALUE (md5(donnees), _date_arrivee, _date_depart);
END;

