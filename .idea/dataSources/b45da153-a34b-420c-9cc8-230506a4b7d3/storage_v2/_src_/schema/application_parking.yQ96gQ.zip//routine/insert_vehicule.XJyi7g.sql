create
    definer = root@localhost procedure insert_vehicule(IN p_plaque char(6), IN p_modele char(20), IN p_couleur char(20),
                                                       IN p_longueur double, IN p_largeur double, IN p_hauteur double,
                                                       IN p_id_utilisateur char(32))
BEGIN
    INSERT INTO Vehicule (plaque, modele, couleur, longueur, largeur, hauteur)
        VALUE (p_plaque, p_modele, p_couleur, p_longueur, p_largeur, p_hauteur);
    INSERT INTO Appartient (plaque, id_utilisateur) VALUE (p_plaque, p_id_utilisateur);
    INSERT INTO Locataire (id_utilisateur) VALUE (p_id_utilisateur) ON DUPLICATE KEY UPDATE id_utilisateur = id_utilisateur;
END;

