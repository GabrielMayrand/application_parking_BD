create
    definer = root@localhost procedure create_data_voiture(IN donnees int)
BEGIN
    DECLARE plaqueNummber char(6);
    IF donnees < 10 THEN
        SET plaqueNummber = CONCAT(0, donnees);
    ELSE
        SET plaqueNummber = donnees;
    END IF;
    INSERT INTO Vehicule (plaque, modele, couleur, longueur, largeur, hauteur)
        VALUE (CONCAT('K', plaqueNummber, 'VHE'), 'Toyota', 'Noir', donnees % 5, donnees % 4, donnees % 3);
END;

