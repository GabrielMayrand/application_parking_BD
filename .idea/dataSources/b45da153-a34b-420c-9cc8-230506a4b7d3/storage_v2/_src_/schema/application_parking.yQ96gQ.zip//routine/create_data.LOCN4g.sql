create
    definer = root@localhost procedure create_data()
BEGIN
    DECLARE donnees INT DEFAULT 99;
    DECLARE courriel char(50);
    DECLARE id_utilisateur char(32);
    WHILE donnees > 0 DO
        SET courriel = CONCAT('test', donnees, '@mail.com');
        SET id_utilisateur = md5(courriel);
        call create_data_utilisateur(donnees, courriel, id_utilisateur);
        call create_data_voiture(donnees, id_utilisateur);
        call create_data_stationnement(donnees, id_utilisateur);
        call create_data_plageHoraire(donnees, id_utilisateur);
        SET donnees = donnees - 1;
    END WHILE;
END;

