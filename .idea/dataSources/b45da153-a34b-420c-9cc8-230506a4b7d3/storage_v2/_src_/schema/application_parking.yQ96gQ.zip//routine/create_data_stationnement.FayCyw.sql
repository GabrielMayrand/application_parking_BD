create
    definer = root@localhost procedure create_data_stationnement(IN donnees int)
BEGIN
    INSERT INTO Stationnement (id_stationnement, prix, longueur, largeur, hauteur, emplacement, jours_d_avance, date_fin)
        VALUE (md5(donnees), donnees % 100, donnees % 10, donnees % 8, donnees % 12, CONCAT('emplacement', donnees),
               donnees % 15, CONCAT('2022-', donnees % 12, '-', donnees % 28));
END;

