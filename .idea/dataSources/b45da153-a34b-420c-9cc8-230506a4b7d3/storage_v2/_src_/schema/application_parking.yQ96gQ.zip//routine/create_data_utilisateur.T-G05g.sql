create
    definer = root@localhost procedure create_data_utilisateur(IN donnees int)
BEGIN
    DECLARE courriel char(50);
    SET courriel = CONCAT('test', donnees, '@mail.com');
    INSERT INTO Utilisateur (id_utilisateur, token, courriel, nom, prenom, mot_de_passe)
        VALUE (md5(courriel), sha1(courriel), courriel, 'Monsieur', CONCAT('Test', donnees), 'password');
    IF (donnees % 2) = 0 THEN
        INSERT INTO Locateur (id_utilisateur, cote) VALUES (md5(courriel), NULL);
    ELSE
        INSERT INTO Locataire (id_utilisateur) VALUES (md5(courriel));
    END IF;
END;

