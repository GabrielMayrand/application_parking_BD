create
    definer = root@localhost procedure insert_plageHoraire_reserver(IN p_debut datetime, IN p_fin datetime,
                                                                    IN p_id_stationnement char(20),
                                                                    IN p_id_plage_horaire char(20),
                                                                    IN p_id_utilisateur char(32))
BEGIN
    INSERT INTO Plage_horaire (id_plage_horaire, date_arrivee, date_depart)
        VALUE (p_id_plage_horaire, p_debut, p_fin);
    INSERT INTO possede (id_plage_horaire, id_stationnement)
        VALUE (p_id_plage_horaire, p_id_stationnement);
    INSERT INTO louer (id_plage_horaire, id_utilisateur)
        VALUE (p_id_plage_horaire, p_id_utilisateur);
    INSERT INTO Reservation (id_plage_horaire)
        VALUE (p_id_plage_horaire);
END;

