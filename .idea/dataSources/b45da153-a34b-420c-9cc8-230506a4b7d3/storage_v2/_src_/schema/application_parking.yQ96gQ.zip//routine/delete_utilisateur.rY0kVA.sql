create
    definer = root@localhost procedure delete_utilisateur(IN p_id_utilisateur char(32), IN p_token char(40))
BEGIN
    DECLARE cur_is_done BOOLEAN DEFAULT FALSE;
    DECLARE cur_id_parking CHAR(20);
    DECLARE cur_id_voiture CHAR(6);
    DECLARE cur_parking CURSOR FOR SELECT id_stationnement FROM Gerer WHERE id_utilisateur = p_id_utilisateur;
    DECLARE cur_voiture CURSOR FOR SELECT plaque FROM Appartient WHERE id_utilisateur = p_id_utilisateur;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_is_done = TRUE;

    IF (SELECT token FROM Utilisateur WHERE id_utilisateur = p_id_utilisateur) = p_token THEN
        OPEN cur_parking;
        boucle: LOOP
            FETCH cur_parking INTO cur_id_parking;
            IF cur_is_done THEN
                LEAVE boucle;
            END IF;
            call delete_stationnement(cur_id_parking);
        END LOOP boucle;
        CLOSE cur_parking;

        SET cur_is_done = FALSE;

        OPEN cur_voiture;
        boucle: LOOP
            FETCH cur_voiture INTO cur_id_voiture;
            IF cur_is_done THEN
                LEAVE boucle;
            END IF;
            call delete_voiture(cur_id_voiture);
        END LOOP boucle;
        CLOSE cur_voiture;

        DELETE FROM Evalue WHERE id_utilisateur_locataire = p_id_utilisateur or id_utilisateur_locateur = p_id_utilisateur;
        DELETE FROM Locataire WHERE id_utilisateur = p_id_utilisateur;
        DELETE FROM Locateur WHERE id_utilisateur = p_id_utilisateur;
        DELETE FROM Utilisateur WHERE id_utilisateur = p_id_utilisateur;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Token invalide';
    END IF;
END;

