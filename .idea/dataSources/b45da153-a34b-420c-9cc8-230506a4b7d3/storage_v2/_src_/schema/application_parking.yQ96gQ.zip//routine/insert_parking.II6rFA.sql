create
    definer = root@localhost procedure insert_parking(IN p_id_stationnement char(32), IN p_id_utilisateur char(32),
                                                      IN p_prix double, IN p_longueur double, IN p_largeur double,
                                                      IN p_hauteur double, IN p_emplacement char(32),
                                                      IN p_joursDavance int, IN p_dateFin date)
BEGIN
    INSERT INTO stationnement (id_stationnement, prix, longueur, largeur, hauteur, emplacement, jours_d_avance, date_fin)
        VALUE (p_id_stationnement, p_prix, p_longueur, p_largeur, p_hauteur, p_emplacement, p_joursDavance, p_dateFin);
    INSERT INTO gerer (id_stationnement, id_utilisateur) VALUE (p_id_stationnement, p_id_utilisateur);
    INSERT INTO Locateur (id_utilisateur, cote) VALUE (p_id_utilisateur, NULL) ON DUPLICATE KEY UPDATE id_utilisateur = id_utilisateur;
END;

