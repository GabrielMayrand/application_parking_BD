create
    definer = root@localhost procedure create_data_stationnement(IN donnees int, IN p_id_utilisateur char(50))
BEGIN
    DECLARE _id_stationnement char(32);
    SET _id_stationnement = md5(donnees);
    INSERT INTO Stationnement (id_stationnement, prix, longueur, largeur, hauteur, emplacement, jours_d_avance, date_fin)
        VALUE (_id_stationnement, donnees % 100, donnees % 10, donnees % 8, donnees % 12, CONCAT('emplacement', donnees),
               donnees % 15, CONCAT('2022-', donnees % 12, '-', donnees % 28));
    IF (donnees % 2) = 0 THEN
        INSERT INTO Gerer (id_utilisateur, id_stationnement) VALUES (p_id_utilisateur, _id_stationnement);
    END IF;
END;

