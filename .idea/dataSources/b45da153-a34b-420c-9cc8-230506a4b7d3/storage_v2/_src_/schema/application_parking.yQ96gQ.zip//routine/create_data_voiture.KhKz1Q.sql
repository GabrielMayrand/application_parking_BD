create
    definer = root@localhost procedure create_data_voiture(IN donnees int, IN p_id_utilisateur char(50))
BEGIN
    DECLARE _plaque char(6);
    IF donnees < 10 THEN
        SET _plaque = CONCAT('K', 0, donnees, 'VHE');
    ELSE
        SET _plaque = CONCAT('K', donnees, 'VHE');
    END IF;
    INSERT INTO Vehicule (plaque, modele, couleur, longueur, largeur, hauteur)
        VALUE (_plaque, 'Toyota', 'Noir', donnees % 5, donnees % 4, donnees % 3);
    IF (donnees % 2) = 1 THEN
        INSERT INTO Appartient (id_utilisateur, plaque) VALUES (p_id_utilisateur, _plaque);
    END IF;
END;

